/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.entidade;
import java.util.Calendar;
/**
 *
 * @author Administrador
 */
public class Animais {
   private int codigo;
   private String nome;
   private String idade;
   private String situacao;
   private String dataadocao;
   private String dataentrada;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getDataadocao() {
        return dataadocao;
    }

    public void setDataadocao(String dataadocao) {
        this.dataadocao = dataadocao;
    }

    public String getData_entrada() {
        return dataentrada;
    }

    public void setData_entrada(String dataentrada) {
        this.dataentrada = dataentrada;
    }

    public String getdataadocao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
