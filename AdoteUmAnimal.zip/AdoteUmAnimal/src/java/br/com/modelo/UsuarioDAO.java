package br.com.modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import br.com.entidade.Animais;
import java.io.PrintWriter;
import java.sql.Date;

public class UsuarioDAO  extends DAO{
     
    public void inserir(Animais usuario) throws Exception {
            try {

                abrirBanco();

                Date data = new java.sql.Date(Calendar.getInstance().getTimeInMillis());

                String query = "INSERT INTO pet (nome,idade,situacao,dataadocao,dataentrada) values(?,?,?,?,?)";
                pst=(PreparedStatement) con.prepareStatement(query);
                pst.setString(1, usuario.getNome());
                pst.setString(2, usuario.getIdade());
                pst.setString(3, usuario.getSituacao());
                pst.setString(4, usuario.getDataadocao());
                pst.setString(5,  data.toString());
                pst.execute();
                fecharBanco();
            } catch (Exception e) {
                System.out.println("Erro " + e.getMessage());
            }
    }
    
    public ArrayList<Animais> pesquisarTudo () throws Exception {//criando o metodo do tipo vetor lista
         ArrayList<Animais> listUsuario = new ArrayList<Animais>();//criando o objeto lista ond serao adicionados os registros
         try{
            abrirBanco();  
            String query = "select * FROM pet order by(codigo) limit 0,10";
            pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            Animais usuario ;
            while (rs.next()){ //lendo cada registro da tabela que será adicionando no vetor
              usuario = new Animais();
              usuario.setCodigo(rs.getInt("codigo"));//pegando o valor do campo codigo e gravando no objeto bean
              usuario.setNome(rs.getString("nome"));
              usuario.setIdade(rs.getString("idade"));
              usuario.setSituacao(rs.getString("situacao"));
              usuario.setDataadocao(rs.getString("dataadocao"));
              usuario.setData_entrada(rs.getString("dataentrada"));

              listUsuario.add(usuario); //adicionando no vetor o registro que veio da tabela
            } 
            
            fecharBanco();
            
        }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
        } 
        return listUsuario;//retornando a lista preenchida para a tela onde esta o html que mostrara para o usuaio a lista
    }
  
    public Animais pesquisar(int id) throws Exception {
    try {
            Animais usuario = new Animais();
            System.out.println("Chegou no pesquisar registo" + id);
            abrirBanco();
            String query = "select * FROM pet where codigo=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                usuario.setCodigo(rs.getInt("codigo"));
                usuario.setNome(rs.getString("nome"));
                usuario.setIdade(rs.getString("idade"));
                usuario.setSituacao(rs.getString("situacao"));
                usuario.setDataadocao(rs.getString("dataadocao"));
                usuario.setData_entrada(rs.getString("dataentrada"));

                return usuario;
            }
            fecharBanco();
    } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
    }
    return null;
	}
    
    public void deletar(Animais usuario) throws Exception{
         abrirBanco();
         String query = "delete from pet where codigo=?";
         pst=(PreparedStatement) con.prepareStatement(query);
         pst.setInt(1, usuario.getCodigo());
         pst.execute();
        fecharBanco();
     }
     
    public void alterar(Animais usuario) throws Exception {
		try {
    abrirBanco();
   
   
    String query = "UPDATE pet SET nome=?,idade=?,situacao=?,dataadocao=? WHERE codigo=?;";
    pst = con.prepareStatement(query);
    pst.setString(1, usuario.getNome());
    pst.setString(2, usuario.getIdade());
    pst.setString(3, usuario.getSituacao());
    pst.setString(4, usuario.getDataadocao());
    pst.setInt(5, usuario.getCodigo());

    pst.execute();
    fecharBanco();
			

    } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
    }
	}
}
